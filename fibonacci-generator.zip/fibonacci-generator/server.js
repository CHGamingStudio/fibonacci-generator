const express = require('express');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static('public'));

wss.on('connection', ws => {
    ws.on('message', message => {
        const num = parseInt(message);
        generateFibonacci(num, ws);
    });
});

function generateFibonacci(n, ws) {
    let a = 0, b = 1, next;
    ws.send(a); 
    if (n > 1) ws.send(b); 

    for (let i = 2; i < n; i++) {
        next = a + b;
        a = b;
        b = next;
        ws.send(next);
    }
}

server.listen(8080, () => {
    console.log('Server running on http://localhost:8080');
});
